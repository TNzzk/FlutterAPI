package com.example.ninelabs_repositories

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
